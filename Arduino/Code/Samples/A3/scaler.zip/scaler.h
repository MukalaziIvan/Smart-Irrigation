#ifndef PIPELINE_H
#define PIPELINE_H

#include <Arduino.h>

class pipeline {
public:
    pipeline();

    void my_scaler();
};

#endif // PIPELINE_H